//Variables used in funtion
var slot1
var slot2
var slot3
var max = 9
var min = 1
//Base funtion
function LotSpin()
{
    //total time
    var currTime = 100;
    //loops the game
    for (var i=1;i<100;i++)
    {
        //decreases time for timer
        setTimeout(function () {
            currTime = currTime -1;
            //
            //displays first slot #
            if (currTime == 75)
            {
                //randomizes a number between 1 and 9
                slot1 = Math.ceil(Math.random() * (max - min))
                //sends randomized number to the "slot1" div
                document.getElementById("slot1").innerHTML = "__" + slot1 + "__";
            }
            //displays second slot #
            else if (currTime == 50)
            {
                slot2 = Math.ceil(Math.random() * (max - min))
                document.getElementById("slot2").innerHTML = "__" + slot2 + "__";
            }
            //displays third slot #
            else if (currTime == 25)
            {
                slot3 = Math.ceil(Math.random() * (max - min))
                document.getElementById("slot3").innerHTML = "__" + slot3 + "__";
            }

            if (currTime < 5)
        {
            if ((slot1 == slot2) && (slot2 == slot3) && (slot3 == slot1) && (slot1 == 9))
            {
                document.getElementById("reward").innerHTML = "Jackpot you're the big winner #1";
            }
            else if ((slot1 == slot2) && (slot2 == slot3) && (slot3 == slot1) && (slot1 != 9))
            {
                document.getElementById("reward").innerHTML = "Congratulation you win #2";
            }
            else if ((slot1 == slot1) && (slot2 == slot1 + 1) && (slot3 == slot1 + 2))
            {
                document.getElementById("reward").innerHTML = "That's pretty good, good job #3";
            }
            else if ((slot1 == slot2) || (slot2 == slot3) || (slot3 == slot1))
            {
                document.getElementById("reward").innerHTML = "At least you didn't lose #4";
            }
            else if ((slot1 == 9) || (slot2 == 9) || (slot3 == 9))
            {
                document.getElementById("reward").innerHTML = "One High two low -_- #5";
            }
            else
            {
                document.getElementById("reward").innerHTML = "Better luck next time";
            }
        }
        },100*i);
        

    }
    
}